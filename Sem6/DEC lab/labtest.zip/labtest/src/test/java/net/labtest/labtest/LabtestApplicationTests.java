package net.labtest.labtest;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LabtestApplicationTests {

	@Test
	void contextLoads() {
	}

}

package net.labtest.labtest.controller;

import org.springframework.stereotype.Controller;

@Controller
public class UserController {
    //displaying users
}

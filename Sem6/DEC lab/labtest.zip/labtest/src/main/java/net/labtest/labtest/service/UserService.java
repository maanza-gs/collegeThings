package net.labtest.labtest.service;

import java.util.List;
import net.labtest.labtest.model.users;
public interface UserService {
    List<users> getAllUsers();
}

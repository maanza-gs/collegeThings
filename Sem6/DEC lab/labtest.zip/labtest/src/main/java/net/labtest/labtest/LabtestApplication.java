package net.labtest.labtest;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LabtestApplication {

	public static void main(String[] args) {
		SpringApplication.run(LabtestApplication.class, args);
	}

}
